
package hello;

import java.util.*;

class Student {
    private int rollNumber;
    private String name;
    private int age;
    private String course;
    private String address;

    public Student(int rollNumber, String name, int age, String course, String address) {
        this.rollNumber = rollNumber;
        this.name = name;
        this.age = age;
        this.course = course;
        this.address = address;
    }

    public int getRollNumber() {
        return rollNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setCourse(String course) {
        this.course = course;
    }
    
    public void setAddress(String address) {
    	this.address = address;
    }

    public String toString() {
        return "Roll No: " + rollNumber + ", Name: " + name + ", Age: " + age + ", Course: " + course + ", Address: " + address;
    }
}

public class StudentManagementSystem {
    private static ArrayList<Student> stuList = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("Student Management System \n");
            System.out.println("1. Add Student");
            System.out.println("2. View Students");
            System.out.println("3. Search Student by Roll Number");
            System.out.println("4. Delete Student by Roll Number");
            System.out.println("5. Update Student by Roll Number");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    viewStudents();
                    break;
                case 3:
                    searchStudent();
                    break;
                case 4:
                    deleteStudent();
                    break;
                case 5:
                	updateStudent();
                    break;
                case 6:
                    System.out.println("Exiting!");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 6);
    }

    private static void addStudent() {
        System.out.print("Enter Roll Number: ");
        int roll = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Age: ");
        int age = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Course: ");
        String course = sc.nextLine();
        
        System.out.print("Enter Address: ");
        String address = sc.nextLine();

        stuList.add(new Student(roll, name, age, course, address));
        System.out.println("Student added successfully.");
    }

    private static void viewStudents() {
        if (stuList.isEmpty()) {
            System.out.println("No students found.");
        } else {
            System.out.println("\nList of Students:");
            for (Student s : stuList) {
                System.out.println(s);
            }
        }
    }

    private static void searchStudent() {
        System.out.print("Enter Roll Number: ");
        int roll = sc.nextInt();
        boolean found = false;

        for (Student s : stuList) {
            if (s.getRollNumber() == roll) {
                System.out.println("Student Found: " + s);
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student not found with Roll No: " + roll);
        }
    }

    private static void deleteStudent() {
        System.out.print("Enter Roll Number to delete: ");
        int roll = sc.nextInt();
        boolean removed = stuList.removeIf(s -> s.getRollNumber() == roll);

        if (removed) {
            System.out.println("Student removed successfully.");
        } else {
            System.out.println("No student found with Roll No: " + roll);
        }
    }

    private static void updateStudent() {
        System.out.print("Enter Roll Number to update: ");
        int roll = sc.nextInt();
        sc.nextLine();

        boolean found = false;
        for (Student s : stuList) {
            if (s.getRollNumber() == roll) {
                System.out.print("Enter new Name: ");
                String name = sc.nextLine();

                System.out.print("Enter new Age: ");
                int age = sc.nextInt();
                sc.nextLine();

                System.out.print("Enter new Course: ");
                String course = sc.nextLine();
                
                System.out.print("Enter new Address: ");
                String address = sc.nextLine();

                s.setName(name);
                s.setAge(age);
                s.setCourse(course);
                s.setAddress(address);

                System.out.println("Student updated successfully.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student not found with Roll No: " + roll);
        }
    }
}
